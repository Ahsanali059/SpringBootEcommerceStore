package in.sp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstController
{
	@RequestMapping("/aaa")
	public String openFirstPage()
	{
		System.out.println("FirstController handler method 1");
		return "firstpage";
	}
	
	@RequestMapping("/bbb")
	public String openSecondPage()
	{
		System.out.println("FirstController handler method 2");
		return "secondpage";
	}
}
