package in.sp.beans;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

public class Student
{
	@Size(min = 3, max = 10, message = "Name is not valid")
	private String name;
	
//	@Min(value = 18)
//	@Max(value = 80)
	@Range(min = 18, max = 80)
	private int age;
	
	@Past
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dob;
	
	@Future
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date booking;
	
	@NotEmpty
	@Email
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getBooking() {
		return booking;
	}
	public void setBooking(Date booking) {
		this.booking = booking;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
