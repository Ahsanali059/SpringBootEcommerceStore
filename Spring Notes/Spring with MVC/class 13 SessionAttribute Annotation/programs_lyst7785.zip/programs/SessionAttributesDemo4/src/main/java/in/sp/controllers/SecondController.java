package in.sp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecondController 
{
	@RequestMapping("/bbb")
	public String openSecondPage()
	{
		return "second";
	}
}