package in.sp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes({"m_name", "m_email", "m_gender", "m_city"})
public class FirstController
{
	@RequestMapping("/aaa")
	public String openFirstPage(Model model)
	{
		model.addAttribute("m_name", "Deepak Panwar");
		model.addAttribute("m_email", "deepak@gmail.com");
		model.addAttribute("m_gender", "Male");
		model.addAttribute("m_city", "Chandigarh");
		
		return "first";
	}
	
	@RequestMapping("/bbb")
	public String openSecondPage()
	{
		return "second";
	}
}
