package in.sp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@SessionAttributes("m_name")
public class FirstController
{
	@RequestMapping("/aaa")
	public String openFirstPage(Model model)
	{
		//----------100 lines of codes----------
		String name = "Deepak Panwar";
		model.addAttribute("m_name", name);
		
		return "first";
	}
	
	@RequestMapping("/bbb")
	public String openSecondPage(SessionStatus sessionStatus)
	{
		sessionStatus.setComplete();
		return "second";
	}
	
	@RequestMapping("/ccc")
	public String openThirdPage()
	{
		return "third";
	}
}
