package in.sp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("m_name")
public class FirstController
{
	@RequestMapping("/aaa")
	public String openFirstPage(Model model)
	{
		//----------100 lines of codes----------
		String name = "Deepak Panwar";
		model.addAttribute("m_name", name);
		
		return "first";
	}
	
	@RequestMapping("/bbb")
	public String openSecondPage()
	{
		return "second";
	}
}
