
package in.sp.services;

import in.sp.dao.LoginDao;
import in.sp.model.UserDetails;

public class LoginService 
{
    public UserDetails loginService(String email, String password)
    {
        LoginDao ld=new LoginDao();
        UserDetails ud = ld.loginUserDao(email, password);
        return ud;
    }
}
