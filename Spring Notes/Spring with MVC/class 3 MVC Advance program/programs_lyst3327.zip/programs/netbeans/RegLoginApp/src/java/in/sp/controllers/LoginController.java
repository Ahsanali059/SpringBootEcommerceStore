
package in.sp.controllers;

import in.sp.model.UserDetails;
import in.sp.services.LoginService;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginController extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        String email2 = req.getParameter("email1");
        String pass2 = req.getParameter("password1");
        
        LoginService ls=new LoginService();
        UserDetails ud = ls.loginService(email2, pass2);
        if(ud != null)
        {
            HttpSession session = req.getSession();
//            session.setAttribute("session_name", ud.getName());
//            session.setAttribute("session_email", ud.getEmail());
//            session.setAttribute("session_gender", ud.getGender());
//            session.setAttribute("session_city", ud.getCity());
            session.setAttribute("session_userdetails", ud);
            
            resp.sendRedirect("profile.jsp");
        }
        else
        {
            req.setAttribute("message", "fail");
            RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
            rd.include(req, resp);
        }
    }
}
