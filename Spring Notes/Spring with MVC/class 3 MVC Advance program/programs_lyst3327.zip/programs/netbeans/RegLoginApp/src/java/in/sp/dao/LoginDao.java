
package in.sp.dao;

import in.sp.dbcon.DbConnection;
import in.sp.model.UserDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao
{
    public UserDetails loginUserDao(String email, String password)
    {
        UserDetails ud = null;
        try
        {
            Connection con = DbConnection.getConnect();
            
            PreparedStatement ps=con.prepareStatement("select * from register where email=? and password=?");
            ps.setString(1, email);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                String name1 = rs.getString("name");
                String email1 = rs.getString("email");
                String gender1 = rs.getString("gender");
                String city1 = rs.getString("city");
                
                ud=new UserDetails();
                ud.setName(name1);
                ud.setEmail(email1);
                ud.setGender(gender1);
                ud.setCity(city1);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        return ud;
    }
}
