package in.sp.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.sp.entity.Student;
import in.sp.resources.SpringConfigFile;
import in.sp.services.StudentService;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigFile.class);
        
        StudentService stdService = (StudentService) context.getBean("studentService");
        
//        Student std = stdService.getStdDetailsByEmailService("ccc@gmail.com");
//        System.out.println("Id : "+std.getId());
//        System.out.println("Name : "+std.getName());
//        System.out.println("Marks : "+std.getMarks());
        
        
        List<Student> std_list = stdService.getAllStdDetailsGreaterMarksService(80.00f);
        for(Student std : std_list)
        {
        	System.out.println("Id : "+std.getId());
        	System.out.println("Name : "+std.getName());
        	System.out.println("Marks : "+std.getMarks());
        	System.out.println("-----------------------");
        }
    }
}
