package in.sp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.entity.Student;
import in.sp.repository.StudentRepository;

@Service
public class StudentService 
{
	@Autowired
	private StudentRepository studentRepository;
	
	public Student getStdDetailsByEmailService(String email)
	{
		Student std = studentRepository.findByEmail(email);
		return std;
	}
	
	public List<Student> getAllStdDetailsGreaterMarksService(float marks)
	{
		return studentRepository.findByMarksGreaterThan(marks);
	}
}
