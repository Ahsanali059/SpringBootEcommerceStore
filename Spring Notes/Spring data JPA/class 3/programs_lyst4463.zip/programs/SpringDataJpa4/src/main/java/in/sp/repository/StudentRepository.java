package in.sp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.sp.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>
{
	@Query("SELECT s FROM Student s WHERE s.email = :stdEmail")
	public Student getStdDetailsByEmail(@Param("stdEmail") String email);
	
	@Query("SELECT s FROM Student s WHERE s.marks > :stdMarks")
	public List<Student> getByMarksGreaterThan(@Param("stdMarks") float marks);
}