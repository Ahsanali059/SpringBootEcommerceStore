package in.sp.main;

import org.springframework.data.jpa.repository.JpaRepository;

public class App 
{
    public static void main( String[] args )
    {
        
    }
}
