package in.sp.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import in.sp.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("main-persistence-unit");
        EntityManager em = emf.createEntityManager();
        
        try
        {
        	String jpql_query = "SELECT s.id, s.name FROM Student s";
        	TypedQuery<Object[]> query = em.createQuery(jpql_query, Object[].class);
        	
        	List<Object[]> obj_list = query.getResultList();
        	
        	for(Object[] obj : obj_list)
        	{
        		int id = (int) obj[0];
        		String name = (String) obj[1];
        		
        		System.out.println("Id : "+id);
        		System.out.println("Name : "+name);
        		
        		System.out.println("---------------------------");
        	}
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        finally
        {
			em.close();
			emf.close();
		}
    }
}
