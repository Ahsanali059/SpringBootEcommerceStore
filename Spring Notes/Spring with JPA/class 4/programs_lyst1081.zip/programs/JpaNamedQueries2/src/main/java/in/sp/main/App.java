package in.sp.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import in.sp.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("main-persistence-unit");
        EntityManager em = emf.createEntityManager();
        
        try
        {
        	TypedQuery<Student> query1 = em.createNamedQuery("getAllStdDetails", Student.class);
        	List<Student> std_list1 = query1.getResultList();
        	for(Student std1 : std_list1)
        	{
        		System.out.println("Id : "+std1.getId());
        		System.out.println("Name : "+std1.getName());
        		System.out.println("Rollno : "+std1.getRollno());
        		System.out.println("Marks : "+std1.getMarks());
        		System.out.println("-----------------------------");
        	}
        	
        	//------------------------------------------------------------------------------------------
        	
        	TypedQuery<Student> query2 = em.createNamedQuery("getStdDetailsById", Student.class);
        	query2.setParameter("stdId", 2);
        	Student std2 = query2.getSingleResult();
        	System.out.println("Hello "+std2.getName()+", you got "+std2.getMarks()+"% marks");
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
        finally
        {
        	em.close();
        	emf.close();
        }
    }
}
