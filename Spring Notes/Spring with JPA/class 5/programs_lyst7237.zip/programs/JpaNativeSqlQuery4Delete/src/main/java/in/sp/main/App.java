package in.sp.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import in.sp.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("main-persistence-unit");
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();
        
        try
        {
        	et.begin();
        	
        	String native_sql_query = "DELETE FROM std_details WHERE std_id = :stdId";
        	Query query = em.createNativeQuery(native_sql_query, Student.class);
        	query.setParameter("stdId", 4);
        	
        	int count = query.executeUpdate();
        	if(count > 0)
        	{
        		System.out.println("success");
        		et.commit();
        	}
        	else
        	{
        		System.out.println("fail");
        		et.rollback();
        	}
        }
        catch(Exception e)
        {
        	et.rollback();
        	e.printStackTrace();
        }
        finally
        {
        	em.close();
        	emf.close();
        }
    }
}
