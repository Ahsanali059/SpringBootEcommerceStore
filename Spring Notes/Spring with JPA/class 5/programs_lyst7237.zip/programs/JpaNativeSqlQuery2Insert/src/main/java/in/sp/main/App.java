package in.sp.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import in.sp.entity.Student;

public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("main-persistence-unit");
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();
        
        try
        {
        	et.begin();
        	
        	String native_sql_query = "INSERT into std_details(std_id, std_name, std_rollno, std_marks) VALUES(:stdId, :stdName, :stdRollno, :stdMarks)";
        	Query query = em.createNativeQuery(native_sql_query, Student.class);
        	query.setParameter("stdId", 4);
        	query.setParameter("stdName", "ddd");
        	query.setParameter("stdRollno", 104);
        	query.setParameter("stdMarks", 74.75f);
        	
        	int count = query.executeUpdate();
        	if(count > 0)
        	{
        		System.out.println("success");
        		et.commit();
        	}
        	else
        	{
        		System.out.println("fail");
        		et.rollback();
        	}
        }
        catch(Exception e)
        {
        	et.rollback();
        	e.printStackTrace();
        }
        finally
        {
        	em.close();
        	emf.close();
        }
    }
}
