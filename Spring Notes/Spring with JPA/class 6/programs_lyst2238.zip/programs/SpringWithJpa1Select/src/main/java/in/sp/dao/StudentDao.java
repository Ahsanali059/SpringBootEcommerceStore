package in.sp.dao;

public interface StudentDao
{
	public void searchStudent(int id);
}
