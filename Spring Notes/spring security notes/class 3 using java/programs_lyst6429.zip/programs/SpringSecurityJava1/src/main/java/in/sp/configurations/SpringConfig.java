package in.sp.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

//class in replacement of myds-servlet.xml file (spring config file)

@Configuration
@ComponentScan("in.sp.controllers")
public class SpringConfig 
{
	@Bean
	public InternalResourceViewResolver myViewResolver()
	{
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
}